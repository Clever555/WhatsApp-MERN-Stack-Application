import React from 'react';
import { Avatar } from '@material-ui/core';
import './SidebarChat.css';

function SidebarChat() {
  return (
<div className='SidebarChat'> 
  <Avatar/>
  <div className='SidebarChat_info'>
   <h2>Room Name</h2>
   <p>This is The Last Message</p>
   </div>
  </div>
  );
}
export default SidebarChat;