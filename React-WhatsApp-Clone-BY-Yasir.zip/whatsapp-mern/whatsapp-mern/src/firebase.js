const firebaseConfig = {
  apiKey: "AIzaSyD244jO4qRV5AosyNkZdym79FzTixAJlJw",
  authDomain: "whatsapp-mern-26804.firebaseapp.com",
  projectId: "whatsapp-mern-26804",
  storageBucket: "whatsapp-mern-26804.appspot.com",
  messagingSenderId: "1093373501407",
  appId: "1:1093373501407:web:8d88a62596689065d3ae6a"
};