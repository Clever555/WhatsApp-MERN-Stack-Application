import React from 'react';
import './Chat.css';
import { Avatar, IconButton } from '@material-ui/core';
import AttachFileIcon from '@material-ui/icons/AttachFile';
import MoreVertIcon from '@material-ui/icons/MoreVert';
import SearchOutlined from '@material-ui/icons/SearchOutlined';
import InsertEmoticonIcon from '@material-ui/icons/InsertEmoticon';
import MicIcon from '@material-ui/icons/Mic';

function Chat() {
  return (
    <div className="chat">
      <div className="chat_header">
      <Avatar/>
       <div className="chat_headerInfo">
        <h3>Room Name</h3>
         <p>Last Seen At ..... </p>
       </div>
        <div className='chat_headerRight'>
          <IconButton>
            <SearchOutlined />
          </IconButton>
          <IconButton>
            <AttachFileIcon />
          </IconButton>
          <IconButton>
            <MoreVertIcon />
          </IconButton>
        </div>
      </div>

      <div className="chat_body">

       <p className='chat_message'>
        <span className="chat_name">Yasir</span> 
        This is a Message
        <span className='chat_timestamp'>
         {new Date().toLocaleTimeString()}</span>
       </p>

       <p className='chat_message chat_reciver'>
        <span className="chat_name">Yasir</span> 
        Message Recived
        <span className='chat_timestamp'>
         {new Date().toLocaleTimeString()}</span>
       </p>
      </div>


      <div className="chat_footer">
       <InsertEmoticonIcon/>
        <form>
         <input placeholder='Type A Message' type='text'/>
         <button type='submit'>
         Send a Message
        </button>
        </form>
        <MicIcon/>
      </div>

      
    </div>
  );
}

export default Chat;